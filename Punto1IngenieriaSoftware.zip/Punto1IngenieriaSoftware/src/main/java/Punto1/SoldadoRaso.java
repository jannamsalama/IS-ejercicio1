/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto1;

/**
 *
 * @author Jajajannam
 */
public class SoldadoRaso implements Unidad {

	SoldadoRaso() {
		throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
	}
    @Override
    public int getAtaque() {
        return 1;
    }

    @Override
    public int getDefensa() {
        return 1;
    }

    @Override
    public int getMovimiento() {
        return 1;
    }

    @Override
    public String descripcion() {
        return "Soldado Raso (Ataque: 1, Defensa: 1, Movimiento: 1)";
    }
}
