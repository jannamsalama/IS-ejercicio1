/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Punto1;

/**
 *
 * @author Jajajannam
 */
public class Punto1IngenieriaSoftware {

public static void main(String[] args) {

}