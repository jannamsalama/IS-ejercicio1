/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto1;

/**
 *
 * @author Jajajannam
 */
public class Escudo extends DecoradorUnidad {
    public Escudo(Unidad unidad) {
        super(unidad);
    }

    @Override
    public int getDefensa() {
        return unidad.getDefensa() * 2;
    }

    @Override
    public String descripcion() {
        return unidad.descripcion() + " + Escudo (Defensa x2)";
    }
}