/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto1;

/**
 *
 * @author Jajajannam
 */
public interface Unidad {
	   int getAtaque();
    int getDefensa();
    int getMovimiento();
    String descripcion();
}