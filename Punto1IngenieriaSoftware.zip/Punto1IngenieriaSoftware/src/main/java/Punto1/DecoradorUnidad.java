/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Punto1;

/**
 *
 * @author Jajajannam
 */
public abstract class DecoradorUnidad implements Unidad {
    protected Unidad unidad;

    public DecoradorUnidad(Unidad unidad) {
        this.unidad = unidad;
    }

    @Override
    public int getAtaque() {
        return unidad.getAtaque();
    }

    @Override
    public int getDefensa() {
        return unidad.getDefensa();
    }

    @Override
    public int getMovimiento() {
        return unidad.getMovimiento();
    }

    @Override
    public String descripcion() {
        return unidad.descripcion();
    }
}