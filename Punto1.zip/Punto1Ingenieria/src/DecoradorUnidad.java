/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SALA
 */
public abstract class DecoradorUnidad implements Unidad {
    protected Unidad unidadDecorada;

    public DecoradorUnidad(Unidad unidadDecorada) {
        this.unidadDecorada = unidadDecorada;
    }

    @Override
    public int getAtaque() {
        return unidadDecorada.getAtaque();
    }

    @Override
    public int getDefensa() {
        return unidadDecorada.getDefensa();
    }

    @Override
    public int getMovimiento() {
        return unidadDecorada.getMovimiento();
    }

    @Override
    public String getDescripcion() {
        return unidadDecorada.getDescripcion();
    }
}
