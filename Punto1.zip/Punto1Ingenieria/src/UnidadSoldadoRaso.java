/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SALA
 */
public class UnidadSoldadoRaso implements Unidad {
    private static final String DESCRIPCION = "Soldado Raso";
    private static final int ATAQUE = 1;
    private static final int DEFENSA = 1;
    private static final int MOVIMIENTO = 1;

    @Override
    public int getAtaque() {
        return ATAQUE;
    }

    @Override
    public int getDefensa() {
        return DEFENSA;
    }

    @Override
    public int getMovimiento() {
        return MOVIMIENTO;
    }

    @Override
    public String getDescripcion() {
        return DESCRIPCION;
    }
}