/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author SALA
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Unidad soldado = new UnidadSoldadoRaso();

        // Decorar la unidad con un escudo
        soldado = new ComplementoEscudo(soldado);

        // Decorar la unidad con una pistola
        soldado = new ComplementoPistola(soldado);

        // Obtener los atributos de la unidad decorada
        int ataque = soldado.getAtaque();
        int defensa = soldado.getDefensa();
        int movimiento = soldado.getMovimiento();
        String descripcion = soldado.getDescripcion();

        // Mostrar la información de la unidad decorada
        System.out.println("Unidad: " + descripcion);
        System.out.println("Ataque: " + ataque);
        System.out.println("Defensa: " + defensa);
        System.out.println("Movimiento: " + movimiento);
    }

}





