/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SALA
 */
public class ComplementoPistola extends DecoradorUnidad {
    private static final String DESCRIPCION = " con Pistola";
    private static final int ATAQUE_MULTIPLICADOR = 2;

    public ComplementoPistola(Unidad unidadDecorada) {
        super(unidadDecorada);
    }

    @Override
    public int getAtaque() {
        return super.getAtaque() * ATAQUE_MULTIPLICADOR;
    }

    @Override
    public String getDescripcion() {
        return super.getDescripcion() + DESCRIPCION;
    }
}