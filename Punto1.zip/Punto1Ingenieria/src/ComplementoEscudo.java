/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author SALA
 */
public class ComplementoEscudo extends DecoradorUnidad {
    private static final String DESCRIPCION = " con Escudo";
    private static final int DEFENSA_MULTIPLICADOR = 2;

    public ComplementoEscudo(Unidad unidadDecorada) {
        super(unidadDecorada);
    }

    @Override
    public int getDefensa() {
        return super.getDefensa() * DEFENSA_MULTIPLICADOR;
    }

    @Override
    public String getDescripcion() {
        return super.getDescripcion() + DESCRIPCION;
    }
}
