/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller2;
import taller2.InstrumentoMusical;

/**
 *
 * @author SALA
 */
public class DobleNodo {
    private InstrumentoMusical dato;
    private DobleNodo nodoAnterior;
    private DobleNodo nodoSiguiente;

    public DobleNodo(InstrumentoMusical dato) {
        this.dato = dato;
        this.nodoAnterior = null;
        this.nodoSiguiente = null;
        
    }

    public InstrumentoMusical getDato() {
        return dato;
    }

    public void setDato(InstrumentoMusical dato) {
        this.dato = dato;
    }

    public DobleNodo getNodoAnterior() {
        return nodoAnterior;
    }

    public void setNodoAnterior(DobleNodo nodoAnterior) {
        this.nodoAnterior = nodoAnterior;
    }

    public DobleNodo getNodoSiguiente() {
        return nodoSiguiente;
    }

    public void setNodoSiguiente(DobleNodo nodoSiguiente) {
        this.nodoSiguiente = nodoSiguiente;
    }
    
    
}
