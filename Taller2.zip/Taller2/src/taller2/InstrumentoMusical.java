/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller2;

/**
 *
 * @author SALA
 */
public class InstrumentoMusical {
    
    private String Nombre, TipoInstrumento;
    private double precio;

    public InstrumentoMusical(String Nombre, String TipoInstrumento, double precio) {
        this.Nombre = Nombre;
        this.TipoInstrumento = TipoInstrumento;
        this.precio = precio;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getTipoInstrumento() {
        return TipoInstrumento;
    }

    public void setTipoInstrumento(String TipoInstrumento) {
        this.TipoInstrumento = TipoInstrumento;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "InstrumentoMusical{" + "Nombre=" + Nombre + ", TipoInstrumento=" + TipoInstrumento + ", precio=" + precio + '}';
    }
    
    public int compareTo(InstrumentoMusical instrumento) {
        return this.Nombre.compareTo(instrumento.Nombre);
    }
    
}


