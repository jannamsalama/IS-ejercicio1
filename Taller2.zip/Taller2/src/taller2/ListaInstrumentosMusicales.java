/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller2;
import java.util.Comparator;
import java.util.NoSuchElementException;
import taller2.ListaDoble;


/**
 *
 * @author SALA
 */
public class ListaInstrumentosMusicales {
    
     private NodoInstrumentoMusical primero;
    private NodoInstrumentoMusical ultimo;
    private int tamaño;
    
    
    public ListaInstrumentosMusicales() {
        this.primero = null;
        this.ultimo = null;
        this.tamaño = 0;
    }

    private NodoInstrumentoMusical obtenerNodoPorIndice(int indice) {
       NodoInstrumentoMusical actual = primero;
        for (int i = 0; i < indice; i++) {
            actual = actual.siguiente;
        }
        return actual;
    }

    public class NodoInstrumentoMusical{
        
        public InstrumentoMusical instrumento;
        public NodoInstrumentoMusical siguiente;
        public NodoInstrumentoMusical anterior;

        public NodoInstrumentoMusical(InstrumentoMusical instrumento) {
            this.instrumento = instrumento;
            this.siguiente = null;
            this.anterior = null;
        }
    }
    
      public boolean listaVacia(){
        return this.primero == null;
    }
    
//métodos
  
public void mostrarAscendente() {
    NodoInstrumentoMusical actual = this.primero;
    while (actual != null) {
        System.out.println(actual.instrumento);
        actual = actual.siguiente;
    }
}

public void mostrarDescendente() {
    NodoInstrumentoMusical actual = this.ultimo;
    while (actual != null) {
        System.out.println(actual.instrumento);
        actual = actual.anterior;
    }
}
      


//public void mostrarListaDescendente() {
  ///  NodoInstrumentoMusical aux = ultimo;
    //while (aux != null) {
      //  System.out.println(aux.instrumento.getNombre());
        //aux = aux.anterior;
    //}
//}
     


  public void agregarInicio(InstrumentoMusical instrumento) {
        NodoInstrumentoMusical nuevo = new NodoInstrumentoMusical(instrumento);
        if (listaVacia()) {
            primero = nuevo;
            ultimo = nuevo;
        } else {
            nuevo.siguiente = primero;
            primero.anterior = nuevo;
            primero = nuevo;
        }
        tamaño++;
    }
  
   public void agregarFinal(InstrumentoMusical instrumento) {
        NodoInstrumentoMusical nuevo = new NodoInstrumentoMusical(instrumento);
        if (listaVacia()) {
            primero = nuevo;
            ultimo = nuevo;
        } else {
            ultimo.siguiente = nuevo;
            nuevo.anterior = ultimo;
            ultimo = nuevo;
        }
        tamaño++;
    }
   
   public void mostrarPorPrecioAscendente() {
    InstrumentoMusical[] arreglo = new InstrumentoMusical[this.tamaño];
    NodoInstrumentoMusical actual = this.primero;
    int i = 0;
    while (actual != null) {
        arreglo[i] = actual.instrumento;
        actual = actual.siguiente;
        i++;
    }
    for (int j = 0; j < arreglo.length - 1; j++) {
        for (int k = 0; k < arreglo.length - j - 1; k++) {
            if (arreglo[k].getPrecio() > arreglo[k + 1].getPrecio()) {
                InstrumentoMusical temp = arreglo[k];
                arreglo[k] = arreglo[k + 1];
                arreglo[k + 1] = temp;
            }
            
              }
    }
    for (InstrumentoMusical instrumento : arreglo) {
        System.out.println(instrumento);
    }
 
   
 }
   
   public void mostrarPorPrecioDescendente() {
    InstrumentoMusical[] arreglo = new InstrumentoMusical[this.tamaño];
    NodoInstrumentoMusical actual = this.primero;
    int i = 0;
    while (actual != null) {
        arreglo[i] = actual.instrumento;
        actual = actual.siguiente;
        i++;
    }
    for (int j = 0; j < arreglo.length - 1; j++) {
        for (int k = 0; k < arreglo.length - j - 1; k++) {
            if (arreglo[k].getPrecio() < arreglo[k + 1].getPrecio()) {
                InstrumentoMusical temp = arreglo[k];
                arreglo[k] = arreglo[k + 1];
                arreglo[k + 1] = temp;
            }
        }
    }
    for (InstrumentoMusical instrumento : arreglo) {
        System.out.println(instrumento);
    }
}

 
  public void agregarPorIndice(int indice, InstrumentoMusical instrumento) {
        if (indice < 0 || indice > tamaño) {
            throw new IndexOutOfBoundsException("Índice fuera de rango.");
        }
        if (indice == 0) {
            agregarInicio(instrumento);
        } else if (indice == tamaño) {
            agregarFinal(instrumento);
        } else {
            NodoInstrumentoMusical actual = obtenerNodoPorIndice(indice);
            NodoInstrumentoMusical nuevo = new NodoInstrumentoMusical(instrumento);
            nuevo.siguiente = actual;
            nuevo.anterior = actual.anterior;
            actual.anterior.siguiente = nuevo;
            actual.anterior = nuevo;
            tamaño++;
        }
    }
  
public InstrumentoMusical eliminarInicio() {
    if (listaVacia()) {
        System.out.println("La lista está vacía, no se puede eliminar ningún elemento.");
    } 
    InstrumentoMusical eliminado = primero.instrumento;
   if (primero == ultimo) {
            primero = null;
            ultimo = null;
        } else {
            primero = primero.siguiente;
            primero.anterior = null;
        }
        tamaño--;
        return eliminado;
    }

public InstrumentoMusical eliminarFinal() {
        if (listaVacia()) {
            throw new NoSuchElementException("La lista está vacía.");
        }
        InstrumentoMusical eliminado = ultimo.instrumento;
        if (primero == ultimo) {
            primero = null;
            ultimo = null;
        } else {
            ultimo = ultimo.anterior;
            ultimo.siguiente = null;
        }
        tamaño--;
        return eliminado;
    }

public InstrumentoMusical eliminarPorIndice(int indice) {
        if (listaVacia()) {
            throw new NoSuchElementException("La lista está vacía.");
        }
        if (indice < 0 || indice >= tamaño) {
            throw new IndexOutOfBoundsException("Índice fuera de rango.");
        }
        if (indice == 0) {
            return eliminarInicio();
        } else if (indice == tamaño - 1) {
            return eliminarFinal();
        } else {
            NodoInstrumentoMusical actual = obtenerNodoPorIndice(indice);
            InstrumentoMusical eliminado = actual.instrumento;
            actual.anterior.siguiente = actual.siguiente;
            actual.siguiente.anterior = actual.anterior;
            tamaño--;
            return eliminado;
        }
    }

public void aplicarDescuentoPorTipo(String tipoInstrumento, double descuento) {
        NodoInstrumentoMusical actual = primero;
        while (actual != null) {
            if (actual.instrumento.getTipoInstrumento().equals(tipoInstrumento)) {
                double precioDescuento = actual.instrumento.getPrecio() * (1 - descuento);
                actual.instrumento.setPrecio(precioDescuento);
            }
            actual = actual.siguiente;
        }
    }

public InstrumentoMusical buscarPorNombre(String nombre) {
    NodoInstrumentoMusical actual = this.primero;
    while (actual != null) {
        if (actual.instrumento.getNombre().equals(nombre)) {
            return actual.instrumento;
        }
        actual = actual.siguiente;
    }
    return null;
}

   public ListaInstrumentosMusicales generarListaPorTipo(String tipoInstrumento) {
        ListaInstrumentosMusicales listaTipo = new ListaInstrumentosMusicales();
        NodoInstrumentoMusical actual = primero;
        while (actual != null) {
            if (actual.instrumento.getTipoInstrumento().equals(tipoInstrumento)) {
                listaTipo.agregarFinal(actual.instrumento);
            }
            actual = actual.siguiente;
        }
        return listaTipo;
    }
   
   public String toString() {
        StringBuilder sb = new StringBuilder();
        NodoInstrumentoMusical actual = primero;
        while (actual != null) {
            sb.append(actual.instrumento.toString()).append("\n");
            actual = actual.siguiente;
        }
        return sb.toString();
    }
}
  



