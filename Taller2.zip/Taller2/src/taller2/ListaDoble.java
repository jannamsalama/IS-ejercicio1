/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller2;
import taller2.InstrumentoMusical;

/**
 *
 * @author SALA
 */
public class ListaDoble {
    
    //Atributos
    private InstrumentoMusical instrumento;
    private ListaDoble siguiente;
    private ListaDoble anterior;
    
    public ListaDoble(InstrumentoMusical instrumento){
    this.instrumento = instrumento;
    }

    public InstrumentoMusical getInstrumento() {
        return instrumento;
    }

    public void setInstrumento(InstrumentoMusical instrumento) {
        this.instrumento = instrumento;
    }

    public ListaDoble getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(ListaDoble siguiente) {
        this.siguiente = siguiente;
    }

    public ListaDoble getAnterior() {
        return anterior;
    }

    public void setAnterior(ListaDoble anterior) {
        this.anterior = anterior;
    }
       
    
}
