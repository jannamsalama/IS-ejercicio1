/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller2;
import java.util.Arrays;
import javax.swing.JOptionPane;
import taller2.ListaDoble;
import taller2.InstrumentoMusical;

/**
 *
 * @author SALA
 */
public class Taller2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        InstrumentoMusical guitarra1 = new InstrumentoMusical("Guitarra acústica", "Cuerda", 500.0);
        InstrumentoMusical guitarra2 = new InstrumentoMusical("Guitarra eléctrica", "Cuerda", 700.0);
        InstrumentoMusical piano1 = new InstrumentoMusical("Piano de cola", "Teclado", 5000.0);
        InstrumentoMusical piano2 = new InstrumentoMusical("Teclado eléctrico", "Teclado", 800.0);
        InstrumentoMusical bateria1 = new InstrumentoMusical("Batería acústica", "Percusión", 1000.0);
        InstrumentoMusical bateria2 = new InstrumentoMusical("Batería electrónica", "Percusión", 1200.0);
     
            
// Agregamos los objetos a la lista
        ListaInstrumentosMusicales lista = new ListaInstrumentosMusicales();
        lista.agregarFinal(guitarra1);
        lista.agregarFinal(guitarra2);
        lista.agregarFinal(piano1);
        lista.agregarFinal(piano2);
        lista.agregarFinal(bateria1);
        lista.agregarFinal(bateria2);

        // Mostramos la lista original
        System.out.println("Lista original:");
        //System.out.println(lista);
        JOptionPane.showMessageDialog(null, (lista));

        // Ejecutamos algunos métodos de la lista
        

        lista.agregarInicio(new InstrumentoMusical("Violín", "Cuerda", 300.0));
        System.out.println("Lista después de agregar un instrumento al inicio:");
        System.out.println(lista);

        lista.agregarFinal(new InstrumentoMusical("Saxofón", "Viento", 600.0));
        System.out.println("Lista después de agregar un instrumento al final:");
        System.out.println(lista);

        lista.agregarPorIndice(3, new InstrumentoMusical("Flauta", "Viento", 200.0));
        System.out.println("Lista después de agregar un instrumento por índice:");
        System.out.println(lista);

        lista.eliminarInicio();
        System.out.println("Lista después de eliminar un instrumento al inicio:");
        System.out.println(lista);

        lista.eliminarFinal();
        System.out.println("Lista después de eliminar un instrumento al final:");
        System.out.println(lista);

        lista.eliminarPorIndice(4);
        System.out.println("Lista después de eliminar un instrumento por índice:");
        System.out.println(lista);

        lista.aplicarDescuentoPorTipo("Cuerda", 0.1);
        System.out.println("Lista después de aplicar descuento a los instrumentos de cuerda:");
        System.out.println(lista);
        
        System.out.println("Buscar por nombre de instrumento:");
        String nombreBuscar = JOptionPane.showInputDialog("Ingrese el nombre del instrumento que desea buscar");
                InstrumentoMusical instrumentoEncontrado = lista.buscarPorNombre(nombreBuscar);
                if (instrumentoEncontrado != null) {
                    JOptionPane.showMessageDialog(null, instrumentoEncontrado.toString(), "Instrumento encontrado", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "El instrumento no fue encontrado en la lista", "Instrumento no encontrado", JOptionPane.ERROR_MESSAGE);
                }
          
           System.out.println("Buscar por tipo de instrumento:");
           String tipoGenerar = JOptionPane.showInputDialog("Ingrese el tipo de instrumento para generar la lista");
                ListaInstrumentosMusicales listaTipo = lista.generarListaPorTipo(tipoGenerar);
                if (listaTipo != null) {
                    listaTipo.mostrarAscendente();
                } else {
                    JOptionPane.showMessageDialog(null, "No se encontraron instrumentos del tipo ingresado", "Lista vacía", JOptionPane.WARNING_MESSAGE);
                }        
        
        System.out.println("Lista ascendente");
        lista.mostrarAscendente();
        
        System.out.println("Lista descendente");
        lista.mostrarDescendente();
        
        System.out.println("Lista por precio ascendente");
        lista.mostrarPorPrecioAscendente();
        
        System.out.println("Lista por precio descendente");
        lista.mostrarPorPrecioDescendente();
        
        
        
        
        
    }
    
    
}
